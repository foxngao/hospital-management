import React from "react";

const AdminHome = () => {
  return <h2>Chào mừng Admin đến với hệ thống quản trị bệnh viện</h2>;
};

export default AdminHome;
