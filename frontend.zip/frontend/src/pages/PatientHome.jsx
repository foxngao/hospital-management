import React from "react";

const PatientHome = () => {
  return <h2> Giao diện bệnh nhân - xem lịch hẹn, đặt khám, hồ sơ bệnh án</h2>;
};

export default PatientHome;
