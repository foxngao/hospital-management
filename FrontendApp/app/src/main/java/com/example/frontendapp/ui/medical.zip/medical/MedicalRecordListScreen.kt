package com.example.frontendapp.ui.medical

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.frontendapp.viewmodel.MedicalRecordViewModel
import com.example.frontendapp.viewmodel.PatientViewModel

@Composable
fun MedicalRecordListScreen(
    viewModel: MedicalRecordViewModel,
    patientViewModel: PatientViewModel,
    maBN: String,
    navController: NavController
) {
    var selectedRecordId by remember { mutableStateOf<String?>(null) }
    var selectedMonth by remember { mutableStateOf("") }

    val allRecords by viewModel.records
    val patient by patientViewModel.patient
    val daCoHSBA by viewModel.hasHSBA

    val months = allRecords.mapNotNull { it["ngayTao"]?.toString()?.take(7) }.distinct()
    val filteredRecords = if (selectedMonth.isNotBlank()) {
        allRecords.filter { it["ngayTao"]?.toString()?.startsWith(selectedMonth) == true }
    } else {
        allRecords
    }

    LaunchedEffect(maBN) {
        viewModel.fetchRecords(maBN)
        viewModel.checkHSBA(maBN)
        patientViewModel.getPatientByMaBN(maBN)
    }

    Column(modifier = Modifier.padding(16.dp)) {
        Text("\uD83D\uDCC1 Hồ sơ bệnh án", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(8.dp))

        if (patient != null) {
            val maHSBA = patient!!.maBN // gán maHSBA = maBN
            Text("\uD83D\uDC64 Mã BN: ${patient!!.maBN}")
            Text("\uD83D\uDC64 Họ tên: ${patient!!.hoTen}")
            Text("\uD83D\uDC64 Mã hồ sơ bệnh án (HSBA): $maHSBA")
            Text("\uD83D\uDCC5 Số đợt khám: ${allRecords.size}")
        } else {
            Text("⏳ Đang tải thông tin bệnh nhân...")
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (months.isNotEmpty()) {
            DropdownMenuFilter(
                options = months,
                selected = selectedMonth,
                onSelect = { selectedMonth = it }
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        if (filteredRecords.isEmpty()) {
            Text("❗ Không có hồ sơ tháng này", color = MaterialTheme.colorScheme.error)
        } else {
            LazyColumn {
                items(filteredRecords) { record ->
                    val maHSBA = record["maHSBA"]?.toString() ?: return@items
                    val ngayTao = record["ngayTao"]?.toString() ?: "Không rõ"
                    val ghiChu = record["ghiChu"]?.toString() ?: "Không có"
                    val lichSu = record["lichSuBenh"]?.toString() ?: "Không có"
                    val dotKham = record["dotKhamBenh"]?.toString() ?: "Không rõ"

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable {
                                selectedRecordId = maHSBA
                                viewModel.loadDetails(maHSBA)
                            }
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("\uD83D\uDCC5 Ngày lập: $ngayTao")
                            Text("📆 Đợt khám bệnh: $dotKham")
                            Text("🧬 Lịch sử bệnh: $lichSu")
                            Text("📝 Ghi chú: $ghiChu")
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (selectedRecordId != null) {
            MedicalRecordDetailDialog(viewModel, onClose = { selectedRecordId = null })
        }
    }
}

@Composable
fun DropdownMenuFilter(
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Column {
        OutlinedTextField(
            value = selected,
            onValueChange = {},
            label = { Text("Lọc theo tháng") },
            readOnly = true,
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = true }
        )
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = {
                        onSelect(option)
                        expanded = false
                    }
                )
            }
        }
    }
}
