import React from "react";

const DoctorHome = () => {
  return <h2> Giao diện chính của Bác sĩ - lịch khám, bệnh án, bệnh nhân</h2>;
};

export default DoctorHome;
