function NotFoundPage() {
  return (
    <div className="p-8 text-center text-2xl text-red-600">
      404 – Không tìm thấy trang!
    </div>
  );
}
export default NotFoundPage;
