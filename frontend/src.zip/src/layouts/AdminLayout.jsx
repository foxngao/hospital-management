import React from "react";
import { Outlet } from "react-router-dom";

function AdminLayout() {
  return (
    <div className="min-h-screen flex">
      {/* Sidebar */}
      <aside className="w-64 bg-gray-800 text-white p-4 space-y-2">
        <h2 className="text-xl font-bold mb-4">Admin Menu</h2>
        <a href="/admin/taikhoan" className="block hover:bg-gray-700 p-2 rounded">
          📋 Danh sách tài khoản
        </a>
        <a href="/admin/assistants" className="block hover:bg-gray-700 p-2 rounded">
          👥 Quản lý Trợ lý
        </a>
        <a href="/admin/taikhoan/tao-moi" className="block hover:bg-gray-700 p-2 rounded">
          👤 Tạo tài khoản
        </a>
        <a href="/admin/taikhoan/phan-quyen" className="block hover:bg-gray-700 p-2 rounded">
          🛡️ Phân quyền người dùng
        </a>   
        <a href="/admin/khoa" className="block hover:bg-gray-700 p-2 rounded">
          🏥 Quản lý khoa
        </a>
        <a href="/admin/bacsi" className="block hover:bg-gray-700 p-2 rounded">
          🧑‍⚕️ Quản lý bác sĩ
        </a>
        <a href="/admin/nhansu" className="block hover:bg-gray-700 p-2 rounded">
          🧑‍🔬 Quản lý nhân viên y tế
        </a>
        <a href="/admin/benhnhan" className="block hover:bg-gray-700 p-2 rounded">
          🧑‍🦽 Quản lý bệnh nhân
        </a>
        <a href="/admin/lichkham" className="block hover:bg-gray-700 p-2 rounded">
          📅 Quản lý lịch khám
        </a>
        <a href="/admin/xetnghiem" className="block hover:bg-gray-700 p-2 rounded">
          🧪 Quản lý xét nghiệm
        </a>
        <a href="/admin/loaixetnghiem" className="block hover:bg-gray-700 p-2 rounded">
          🧾 Quản lý loại xét nghiệm
        </a>
        <a href="/admin/hosobenhan" className="block hover:bg-gray-700 p-2 rounded">
          📋 Hồ sơ bệnh án
        </a>
        <a href="/admin/thuoc" className="block hover:bg-gray-700 p-2 rounded">
          💊 Quản lý thuốc
        </a>
        <a href="/admin/nhomthuoc" className="block hover:bg-gray-700 p-2 rounded">
          📦 Quản lý nhóm thuốc
        </a>
        <a href="/admin/donvitinh" className="block hover:bg-gray-700 p-2 rounded">
          📐 Quản lý đơn vị tính
        </a>
        <a href="/admin/hoadon" className="block hover:bg-gray-700 p-2 rounded">
          🧾 Quản lý hoá đơn
        </a>


        {/* thêm thêm các mục khác nếu cần */}
      </aside>

      {/* Nội dung */}
      <main className="flex-1 p-6 bg-gray-50">
        <h1 className="text-2xl font-bold mb-4">Admin Dashboard</h1>
        <Outlet />
      </main>
    </div>
  );
}

export default AdminLayout;
