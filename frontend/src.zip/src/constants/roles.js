export const Roles = {
  ADMIN: "ADMIN",
  BACSI: "BACSI",
  BENHNHAN: "BENHNHAN",
};
